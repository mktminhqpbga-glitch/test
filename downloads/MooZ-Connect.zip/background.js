importScripts('shopee-source.js','ai-sites.js','chrome-remote-protocol.js','chrome-remote-diagnostics.js','chrome-relay-channel.js');
importScripts('desktop/muse-background-worker.js');
importScripts('desktop/chrome-relay-worker.js');
importScripts('desktop/ai-activity-worker.js');
